package com.gmh.itics.tesoem.edu.p3gersain1616;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FrmPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frm_principal);
    }
}
